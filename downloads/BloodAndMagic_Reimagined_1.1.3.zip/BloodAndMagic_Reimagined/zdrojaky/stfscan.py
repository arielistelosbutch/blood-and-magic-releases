#!/usr/bin/env python3
"""Scan a Blood & Magic MAIN.STF and (re)build MAIN.MAP / MAP.IDX."""
import struct, sys
ESIZE = 111
def scan(s):
    out = []; o = 0
    while o + 28 <= len(s):
        rn, = struct.unpack_from('<I', s, o)
        comp, us, sz, typ, nh, soh = struct.unpack_from('<HIIHHH', s, o + 4)
        gen, = struct.unpack_from('<H', s, o + 4 + 22)
        if gen != 0xfefe:
            raise SystemExit('bad record at %d' % o)
        out.append((typ, rn, o))
        o += 4 + 24 + soh + (sz if sz else us)
    return out, o
def build_map(recs):
    m = bytearray()
    for typ, rn, off in sorted(recs, key=lambda r: (((r[0] << 16) | r[1]) & 0xffffffff)):
        r = struct.pack('<BIHI', typ, rn, 1, off)
        m += r + b'\0' * (ESIZE - len(r))
    idx = b'main'.ljust(9, b'\0') + struct.pack('<HHH', ESIZE, len(recs), 0) + b'\x01\x00\x00'
    return bytes(m), idx
if __name__ == '__main__':
    s = open(sys.argv[1], 'rb').read()
    recs, end = scan(s)
    print(len(recs), 'records, end', end, 'of', len(s))
    if len(sys.argv) > 3:
        m, idx = build_map(recs)
        open(sys.argv[2], 'wb').write(m); open(sys.argv[3], 'wb').write(idx)
