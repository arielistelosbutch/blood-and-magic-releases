﻿BLOOD & MAGIC REIMAGINED 1.1.0 (1996) - REMASTER CZ
Modern Windows port with Czech translation
==========================================

NEW IN 1.1.0
  - Automatic updates: at startup the game checks GitHub in the background
    for a new version and offers it in the main menu with the release
    notes - DOWNLOAD AND INSTALL / LATER / SKIP THIS VERSION. Nothing is
    downloaded or installed without your consent.
  - SETTINGS -> UPDATES: game version, check now, automatic check on/off,
    report a bug.
  - F7 = report a bug (in the game and in the menus): the game prepares a
    folder with a screenshot and logs and opens an e-mail to the author.
  - Fixed offensive autocast: the Wyrm and others now cast between attacks
    and keep fighting; Wraith and Nymph no longer waste mana.
  - Fixed the movie data setup (cines2.map) on the first install.

An unofficial fan-made mod of the 1996 DOS strategy game Blood & Magic
(Tachyon Studios / Interplay), built from the game's released source code
and ported to SDL2. Runs natively on Windows (no DOSBox), in high
resolution, with many improvements and an optional Czech translation.

YOU NEED THE ORIGINAL GAME
  This package does NOT contain any original game data (graphics, sound,
  movies, maps). You need your own original Blood & Magic CD (1996), in one
  of these forms:
    - the CD in a CD-ROM drive,
    - the game installed on disk (e.g. C:\INTRPLAY\BAM, the original
      installer's default),
    - the CD contents copied into a folder,
    - a CD image: .cue + .bin, .iso, .img, .mdf, .nrg, or GOG-style
      game.ins/game.gog.
  Note: at the time of this release Blood & Magic is not sold digitally
  (not on GOG or Steam), so the original CD is needed.

INSTALLATION
  1. Unzip anywhere writable (e.g. C:\Games\BloodAndMagic or Documents).
     Do not use C:\Program Files - the game keeps its settings, saves and
     data in its own folder. (Or run BloodAndMagic_Reimagined_1.1.0_Setup.exe,
     which also creates Start menu and desktop shortcuts.)
  2. Run BloodAndMagic.exe.
  3. On the first run the game finds the original game by itself: it checks
     CD-ROM drives, the usual install folders on all disks (C:\INTRPLAY\BAM,
     C:\BAM, C:\GAMES..., GOG folders), the game folder and its parent,
     Desktop, Documents and Downloads, including CD images found there.
     If nothing is found, it asks you to choose a folder / CD drive or a
     CD image file.
     Easiest: insert the CD, or put the CD image (e.g. BAM.cue + BAM.bin)
     next to BloodAndMagic.exe.
  4. The needed data (about 215 MB) is copied into the game folder (a small
     window shows the progress), then the game starts. Later runs start
     immediately and need neither the CD nor the image.
  A partial original install (without movies) is completed from the CD or
  CD image.

LANGUAGE
  The game starts in English. Click the Czech flag in the bottom-left
  corner of the main menu to switch to Czech (the British flag switches
  back); the game restarts itself. Also in SETTINGS -> LANGUAGE, or
  czech = 1 in bamport.ini.

PORT CONTROLS
  Alt+Enter     window / fullscreen
  + / -         game speed (50 % - 300 %, saved; default 150 %)
  Ctrl+1..9     store selected units as a group; 1..9 recall (twice = center)
  right-click an ability button (Heal / Repair): auto-cast on/off
                   cooldowns: Cleric 3 s, Paladin 8 s, Gnome 3 s (manual casts too)
                   also OFFENSIVE skills: Wyrm (flame), Enchanter (convert),
                   Harpy (net), Wraith (fear), Nymph (lure). An idle, guarding
                   or fighting unit casts on the best visible enemy: Wyrm the
                   weakest, Enchanter / Harpy the strongest (up to 3 tiles,
                   it steps up to it), Wraith / Nymph when an enemy is in the
                   area of effect. Only with enough mana; wait after each
                   automatic cast: Wyrm 4 s, Harpy 6 s, Wraith 8 s, Nymph and
                   Enchanter 10 s (manual casts are not limited).
  right-click the golem button of a portal: auto-summon on/off
  portal/building selected + right-click on the map: rally point
  F2 / F3 save / load, F5 / F9 quick save / quick load
  mouse wheel   scroll the map (Shift = sideways)
  Shift + right-click: command queue
  A + left-click on the ground: ATTACK-MOVE - the unit / group walks there
                and engages every visible enemy that comes near (4 tiles or
                its range), then carries on; a red flag marks the target.
                With no enemy unit near it also attacks visible enemy
                buildings (units first) and carries on once they fall.
                A + click on an enemy is a normal attack as before; with
                Shift it is queued. Works in network games too.
  hold Alt      health bars over all units and buildings
  F8 music: soundfont / original FM;  F10 picture: sharp / smooth / HD
  F11 CRT scanlines;  F12 screenshot
  F7            REPORT A BUG: saves bugreports\bugreport_... (screenshot,
                bamport.log, bamport.ini, info.txt ...), opens that folder
                and an e-mail to the author - describe what happened and
                attach the files from the folder.
  F1            help: the port's controls over the screen (the game waits,
                a network game keeps running); any key or click closes it.
                Works in the menus too.
  . (period)    next IDLE GOLEM: selects and centres a Basal Golem that does
                nothing; pressing again cycles through them. Idle = standing
                doing nothing, or an obelisk whose transferable mana is full
                (10) so it meditates for nothing (manual mana / full pool).
  Options (disk) -> VIDEO VOLUME: volume of the cinematics (sounds and music
                have their own SOUNDS / MUSIC sliders; saved)
  In the wide map view the in-game windows (options, save / load,
  encyclopedia, objectives, research, tutorial) are centred on the screen.

NEW IN THE MAIN MENU
  SKIRMISH on any of 16 maps (also your own), MAP EDITOR, SETTINGS
  (AI difficulty, rush protection, auto mana, music, picture, CRT, view
  width 4:3/16:10/16:9/21:9, health bars ALWAYS / DAMAGED / ALT, language,
  UPDATES, replay intro), TWO PLAYER ->
  NETWORK / INTERNET (TCP port 47100).

PLAYING OVER THE INTERNET / LAN (TWO PLAYER)
  (the same guide is also in HRA_PO_INTERNETU.txt)

  For a two-player game one player HOSTS (waits for the opponent) and the
  other JOINS by typing the host's IP address. The game uses TCP port 47100.

  Both players need:
    – the SAME version of the mod (the same BloodAndMagic.exe). A different
      version is refused ("FAILED TO CONNECT").
    – their own original game (data set up on the first run).

  IN THE GAME
    Host:   MAIN MENU → TWO PLAYER → NETWORK / INTERNET → HOST GAME.
            The game waits for the opponent.
    Joiner: MAIN MENU → TWO PLAYER → NETWORK / INTERNET, click the HOST IP
            ADDRESS box, type the host's address (e.g. 192.168.1.23 or
            100.101.102.103) and click JOIN GAME (or press Enter). The
            address is remembered.
    (Czech menu: DVA HRÁČI → SÍŤ / INTERNET → HOSTOVAT HRU / PŘIPOJIT SE.)
    The joiner keeps trying for 60 seconds, so it does not matter who clicks
    first. Once connected, both pick a character and the battle starts.
    If the host forwarded a different external port, type address:port
    (e.g. 85.12.34.56:47101).

  Which address to type depends on how you are connected:

  A) SAME NETWORK (LAN, same home Wi-Fi)
    1. The host finds his address: Win+R → type cmd → Enter → type ipconfig
       → Enter, and look for "IPv4 Address", e.g. 192.168.1.23.
    2. The host clicks HOST GAME, the other player types that address and
       clicks JOIN GAME.

  B) INTERNET WITH PORT FORWARDING (for experienced users)
    1. The host finds his local address (see A, e.g. 192.168.1.23).
    2. In the router settings (usually http://192.168.1.1 or 192.168.0.1,
       the password is often on the router's label) find "Port Forwarding" /
       "Virtual Server" and add a rule: protocol TCP, external port 47100,
       internal port 47100, target = the host's local address.
    3. The host finds his public address, e.g. at https://ifconfig.me, and
       sends it to the other player.
    4. The host clicks HOST GAME, the other player types the public address
       and clicks JOIN GAME.
    Note: some providers (mobile data, shared networks, CGNAT – the router's
    WAN address starts with 100.64–100.127, 10. etc. and differs from the one
    on ifconfig.me) do not allow port forwarding. Use C instead.

    Windows Firewall: the first time you HOST, Windows asks whether to allow
    the game on networks. Tick "Private networks" (preferably "Public
    networks" too) and click Allow access. If you clicked Cancel: Control
    Panel → Windows Defender Firewall → Allow an app or feature through
    Windows Defender Firewall → Change settings → tick BloodAndMagic.exe
    (Private and Public). Only the host gets this prompt; the joiner does
    not need to set anything.

  C) EASIEST: TAILSCALE OR ZEROTIER (no router setup)
    These free programs create a private network between your computers
    over the internet – the game then works as if on a LAN. Works behind
    CGNAT and on mobile data too.

    TAILSCALE (recommended)
    1. Both players download and install Tailscale from
       https://tailscale.com/download and sign in (Google, Microsoft,
       GitHub… account – the free Personal plan is enough).
    2. The host invites the other player: at https://login.tailscale.com/admin
       → Machines → "…" next to his computer → Share… → copy the link and
       send it to the friend (or invite him into the tailnet via Users →
       Invite users). The friend opens the link, signs in and accepts.
    3. The host finds his Tailscale address: click the Tailscale icon next
       to the clock → his computer's name shows the address 100.x.y.z
       (click to copy). It is also shown on the Machines page.
    4. The host clicks HOST GAME, the other player types 100.x.y.z into the
       HOST IP ADDRESS box and clicks JOIN GAME.

    ZEROTIER (alternative)
    1. The host creates an account at https://my.zerotier.com and a network
       (Create A Network) and gets its Network ID (16 characters).
    2. Both install ZeroTier from https://www.zerotier.com/download, click
       the ZeroTier icon next to the clock → Join New Network… and enter the
       Network ID. When Windows asks whether the PC should be discoverable
       on this network, answer Yes.
    3. On my.zerotier.com, under Members, the host ticks "Auth" for both
       computers. The Managed IPs column shows his computer's address
       (e.g. 10.147.17.5).
    4. The host clicks HOST GAME, the other player types the host's
       ZeroTier address and clicks JOIN GAME.

    The Windows Firewall prompt may appear here too (see B) – allow access.

  IF IT DOES NOT WORK
    – Check that both of you run the same version of the mod.
    – The host must be waiting on the HOST GAME screen before the joiner's
      60 seconds run out.
    – Check the address (a Tailscale address always starts with 100.).
    – Host's firewall / antivirus: allow BloodAndMagic.exe.
    – Port 47100 must not be used by another program (e.g. a second copy
      of the game).
    – In network games auto-cast, auto-summon and rally points are off (both
      computers must stay in sync); attack-move and groups work.

BATTLE STATISTICS
  When the victory / defeat window of a mission or skirmish is closed, a
  statistics screen shows the battle time (game time), units summoned and
  transformed, units lost, enemies killed and buildings destroyed for you
  and the enemy, and the mana gathered / spent. A click or a key goes on
  to the original assessment (or the defeat screen). Not in network games.

HEALTH BARS
  Default DAMAGED: bars over damaged and selected units (and damaged
  buildings); ALWAYS: all units; ALT: only while Alt is held. Holding Alt
  shows all of them in every mode. Enemies hidden in the fog get no bar.

CONTINUING A CAMPAIGN WITH A NEWER VERSION
  Saved games (F2 / F5) only load into the exe that wrote them. So the game
  also writes checkpoint.ini (story, side, missions done, experience,
  research, scores, alignment, characters, map seed) whenever a mission
  starts and when a won mission's assessment is left, and NN.cpt next to
  every save NN.sav. After an update: SINGLE PLAYER -> CONTINUE restarts
  the current mission from its beginning, and loading an old save offers
  to play its mission from the start instead of an error.
  The legendary campaign now goes on after the Hall of Legends (EXIT).

SETTINGS FILE bamport.ini (created on the first run)
  speed = 150, smooth = 2 (HD), fullscreen = 0, czech = 0, skip_intro = 1
  (the intro plays once on the first run), fm_music = 0, view_width = 420
  (320 = 4:3, 380 = 16:10, 420 = 16:9, 560 = 21:9), scroll = 40,
  auto_mana = 1, ai_level = 0, no_rush = 0, crt = 0,
  health_bars = 1 (0 always, 1 damaged + selected, 2 only with Alt),
  video_volume = 127 (cinematics volume 0..127),
  update_check = 1 (look for a new version at startup),
  update_skip = (the version you chose to skip)

UPDATES
  At startup (in the background, it never delays the game) the game looks
  at github.com/arielistelosbutch/blood-and-magic-releases for a new
  version. If there is one, the main menu shows the release notes and:
    DOWNLOAD AND INSTALL - downloads the installer (progress bar, can be
        cancelled), the game closes, the new version is installed into the
        same folder and the game starts again. Settings (bamport.ini),
        saved games, campaign progress and the copied game data are kept.
    LATER - asks again on the next start.
    SKIP THIS VERSION - never asks about this version again (offered only
        on a manual check, or when the next one comes out).
  By hand: SETTINGS -> UPDATES -> CHECK FOR UPDATES; the automatic check
  can be switched off there. Offline nothing happens.
  If the game folder is not writable, the downloaded installer is shown in
  Explorer - run it by hand.

BUG REPORTS (F7)
  Press F7 anywhere in the game or the menus (or SETTINGS -> UPDATES ->
  REPORT A BUG). The game saves a screenshot, bamport.log, bamport.ini,
  checkpoint.ini and info.txt (game version, Windows version, map /
  mission) into bugreports\bugreport_date_time, opens that folder and your
  e-mail program with a prefilled message to the author
  (arielistelosbutch@gmail.com). Describe what happened and attach the
  files. Without an e-mail program write to that address from web mail, or
  use the REPORT ON GITHUB button. Nothing is sent automatically.

TROUBLESHOOTING
  - "The game folder is not writable": move the folder (e.g. C:\Games\).
  - CD not found: insert it, or pick the folder / image when asked.
    Unzip a zipped CD image first.
  - To redo the data setup, delete RES_CFG.HPP; on the next start only
    missing files are copied again.

CREDITS
  Translation and game modifications: Ivo "Arielistelos" Florek
  (original Czech translation: Arielistelos / Pixel Guys, lokalizace.net)
  Blood & Magic (c) 1996 Tachyon Studios / Interplay Productions.
  Third-party software (licences in the "licence" folder):
    SDL2 (zlib), libsmacker (LGPL 2.1), TinySoundFont (MIT),
    libADLMIDI (LGPL), MMPX (MIT), GeneralUser GS soundfont by
    S. Christian Collins (free to redistribute), Lora typeface by The
    Lora Project Authors (SIL Open Font License 1.1; update and bug report
    windows), arrows from DejaVu Sans.
  The port's source code is in the "zdrojaky" folder (LGPL compliance).

Blood & Magic, Forgotten Realms, Advanced Dungeons & Dragons and TSR are
trademarks of their respective owners. This is an unofficial fan project,
not affiliated with the rights holders, and contains no original game data.
